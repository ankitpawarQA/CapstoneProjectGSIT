package org.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Capstone_POM {

	public Capstone_POM(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// enter integer input field
	@FindBy(css = "input[id='number']")
	private WebElement EnterAnInteger;

	// calculate Button
	@FindBy(css = "button[id='getFactorial']")
	private WebElement calculateButton;

	// text over input field
	@FindBy(xpath = "//h1[text()='The greatest factorial calculator!']")
	private WebElement textOverInputField;

	// terms and condition link
	@FindBy(partialLinkText = "Terms and Conditions")
	private WebElement termsAndCondtionLink;

	// privacy link
	@FindBy(partialLinkText = "Privacy")
	private WebElement privacyLink;

	// privacy link
	@FindBy(partialLinkText = "Qxf2 Services")
	private WebElement Qxf2ServicesLink;

	// getters for WebElements

	public WebElement getCalculatebutton() {
		return calculateButton;
	}

	public WebElement getEnterAnInteger() {
		return EnterAnInteger;
	}

	public WebElement gettextOverInputField() {
		return textOverInputField;
	}

	public WebElement gettermsAndCondtionLink() {
		return termsAndCondtionLink;
	}

	public WebElement getprivacyLink() {
		return privacyLink;
	}

	public WebElement getQxf2ServicesLink() {
		return Qxf2ServicesLink;
	}

}
