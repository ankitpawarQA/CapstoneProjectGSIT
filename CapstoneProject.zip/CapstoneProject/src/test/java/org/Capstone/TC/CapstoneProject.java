package org.Capstone.TC;

import java.time.Duration;

import org.POM.Capstone_POM;
import org.baseclass.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class CapstoneProject extends BaseClass {

	Capstone_POM c;

	@BeforeClass
	@Parameters("browser")
	public void setUp(String browserName) throws InterruptedException {
		launchBrowser(browserName);
		c = new Capstone_POM(driver);
		Thread.sleep(1500);
	}

	@Test(priority = 1)
	public void enterIntegerField() {
		boolean EnterAnIntegerDisplay = c.getEnterAnInteger().isDisplayed();
		boolean EnterAnIntegerEnable = c.getEnterAnInteger().isEnabled();

		SoftAssert s = new SoftAssert();
		s.assertEquals(EnterAnIntegerDisplay, true);
		s.assertEquals(EnterAnIntegerEnable, true);
		s.assertAll();
	}

	@Test(priority = 2)
	public void calculateBtn() {
		boolean CalculatebuttonDisplayed = c.getCalculatebutton().isDisplayed();
		boolean CalculatebuttonEnable = c.getCalculatebutton().isEnabled();

		SoftAssert s = new SoftAssert();
		s.assertEquals(CalculatebuttonDisplayed, true);
		s.assertEquals(CalculatebuttonEnable, true);
		s.assertAll();
	}

	@Test(priority = 3)
	public void links() {
		boolean privacyLinkDisplayed = c.getprivacyLink().isDisplayed();
		boolean privacyLinkEnable = c.getprivacyLink().isEnabled();
		boolean termsAndCondtionLinkDisplayed = c.gettermsAndCondtionLink().isDisplayed();
		boolean termsAndCondtionLinkEnable = c.gettermsAndCondtionLink().isEnabled();

		SoftAssert s = new SoftAssert();
		s.assertEquals(privacyLinkDisplayed, true);
		s.assertEquals(privacyLinkEnable, true);
		s.assertAll();
	}

	@Test(priority = 4)
	public void textCheck() {
		String textOverInputFieldText = c.gettextOverInputField().getText();
		String pageTitle = pageTitle();
		String pageUrl = pageUrl();
		String Excpt = "https";
		boolean contains = pageUrl.contains(Excpt);

		SoftAssert s = new SoftAssert();
		s.assertEquals(pageTitle, "Factorial");
		s.assertEquals(pageUrl, "https://qainterview.pythonanywhere.com/");
		s.assertEquals(contains, "URL doesnt not contain 'https'. ");
	}

//	@Test(priority = 5)
//	public void factorialCheck() throws InterruptedException {
//		c.getEnterAnInteger().sendKeys("4");
//		c.getCalculatebutton().click();
//
//		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
//		w.until(ExpectedConditions.visibilityOf((WebElement) By.partialLinkText("The factorial of ")));
//
//		System.out.println(driver.findElement(By.partialLinkText("The factorial of")));
//	}

	@AfterClass
	public void tearDown() {
		quitBrowser();

	}
}
